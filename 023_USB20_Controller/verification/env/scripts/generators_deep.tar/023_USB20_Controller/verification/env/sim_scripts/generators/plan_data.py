"""Plan data of the USB 2.0 controller verification (block level). Edited by hand; gen_plan.py turns it into
requirements.txt, vplan.csv and the tables of verification_plan.md. Every expected behavior cites a requirement ID of
VLSIT_USB20_CONTROLLER_HDS.md; nothing here is taken from RTL bodies (R-103)."""

OWNER = 'dv_usb2'

# Configurations under verification: id -> (wrapper, parameters, reason)
CONFIGS = {
    'cfg_dev_utmi8_axim': ('m_usb2_top_utmi_axim', 'ROLE=0 NUM_EP=4 UTMI_W=8 FIFO_DEPTH=1024 SG_EN=1 LPM_EN=1 TSCALE=256',
                           'device, 8-bit UTMI+, AXI master DMA: main device product configuration'),
    'cfg_dev_utmi16_axim': ('m_usb2_top_utmi_axim', 'ROLE=0 NUM_EP=4 UTMI_W=16 AXI_DATA_W=64 FIFO_DEPTH=1024 TSCALE=256',
                            'device, 16-bit UTMI+ at 30 MHz and 64-bit AXI: second data-width point'),
    'cfg_dev_utmi8_axis': ('m_usb2_top_utmi_axis', 'ROLE=0 NUM_EP=2 UTMI_W=8 FIFO_DEPTH=256 NUM_DMA_CH=2 TSCALE=256',
                           'device, AXI slave windows with external DMA handshake (CFG-MIN of the specification)'),
    'cfg_dev_ulpi_axim': ('m_usb2_top_ulpi_axim', 'ROLE=0 NUM_EP=4 FIFO_DEPTH=1024 LPM_EN=1 TSCALE=256',
                          'device behind a ULPI PHY'),
    'cfg_host_utmi8_axim': ('m_usb2_top_utmi_axim', 'ROLE=1 NUM_HC=8 UTMI_W=8 FIFO_DEPTH=1024 SPLIT_EN=1 SG_EN=1 LPM_EN=1 TSCALE=256',
                            'host with split transactions and scatter-gather'),
    'cfg_host_ulpi_axim': ('m_usb2_top_ulpi_axim', 'ROLE=1 NUM_HC=4 FIFO_DEPTH=1024 TSCALE=256',
                           'host behind a ULPI PHY (DrvVbus, over-current, low power)'),
    'cfg_dual_utmi8_axim': ('m_usb2_top_utmi_axim', 'ROLE=2 NUM_EP=4 NUM_HC=4 FIFO_DEPTH=1024 TSCALE=256',
                            'dual-role build: role selection and both engines present'),
    'cfg_dev_utmi8_axim_pipe': ('m_usb2_top_utmi_axim', 'cfg_dev_utmi8_axim plus PIPE_PHY_IN=1 PIPE_RX=1 PIPE_CRC=1 PIPE_XREG=1 PIPE_MODE=1 RAM_1P=1',
                                'all timing options on: they must be functionally transparent (DEC-029)'),
    'cfg_dev_utmi8_axim_ts1': ('m_usb2_top_utmi_axim', 'cfg_dev_utmi8_axim with TSCALE=1',
                               'real-time timers, required once per timing requirement (REQ-VER-002)'),
    'cfg_unit': ('unit modules', 'm_usb2_fifo, m_usb2_cdc_fifo, m_usb2_xreg, m_usb2_crc5/16, m_usb2_ocp, m_usb2_irq, m_usb2_rst',
                 'formal and unit-level proofs of bounded control logic'),
    'cfg_review': ('none', 'no simulation', 'requirements closed by a recorded review'),
}

# Out of scope: (item, reason, where verified instead)
OUT_OF_SCOPE = [
    ('Analog PHY, serial bit stream, bit stuffing and NRZI', 'inside the UTMI+ or ULPI PHY, outside the DUT boundary', 'PHY vendor qualification and lab test'),
    ('USB-IF compliance and interoperability with real host and device stacks (REQ-VER-003)', 'needs hardware or an emulation platform; no such platform in this environment', 'FPGA prototype or emulation; the plan row records a review of the pre-check list only'),
    ('Scan insertion and ATPG (REQ-DFT-001)', 'needs a DFT tool; RTL-level check is a review of the reset override and clock-gate test enable', 'DFT flow of the integration project'),
    ('FIFO RAM macro internals', 'technology macro; a behavioral model is used', 'memory compiler verification'),
    ('Gate-level and post-layout simulation, sign-off STA', 'no layout flow (DEC-035)', 'integration project'),
    ('AXI4-only features (QoS, region, user)', 'ASM-007 limits the ports to the AXI3 behavior of REF-010', 'not applicable'),
]

# Features (functions): name -> (requirements, priority, method, reason for the method)
FEATURES = {
    'dev_token_addr': ('REQ-FUNC-001;REQ-FUNC-002;REQ-FUNC-007', 'high', 'simulation', 'packet sequences against the protocol model'),
    'crc': ('REQ-FUNC-003', 'high', 'formal+simulation', 'small combinational function: prove against the polynomial, and check in traffic'),
    'data_toggle': ('REQ-FUNC-004', 'high', 'simulation', 'stateful per-endpoint sequences with retries'),
    'ping_nyet': ('REQ-FUNC-005', 'high', 'simulation', 'depends on FIFO space over long sequences'),
    'turnaround': ('REQ-FUNC-006;REQ-FUNC-014;REQ-FUNC-025', 'high', 'simulation', 'cycle measurements at the PHY interface'),
    'packet_size': ('REQ-FUNC-008', 'medium', 'simulation', 'boundary lengths 0, 1, max, max+1'),
    'hb_iso': ('REQ-FUNC-009;REQ-FUNC-033', 'high', 'simulation', 'microframe sequences with data PID order'),
    'host_sof': ('REQ-FUNC-010;REQ-FUNC-037', 'high', 'simulation', 'interval measurement over many frames'),
    'port_reset': ('REQ-FUNC-011', 'high', 'simulation', 'long timers; measured once at TSCALE=1'),
    'hs_chirp': ('REQ-FUNC-012;REQ-FUNC-013;REQ-FUNC-024', 'high', 'simulation', 'timed line-state handshake between BFM and DUT'),
    'host_sched': ('REQ-FUNC-015;REQ-FUNC-032', 'high', 'simulation', 'ordering and budget over frames with several channels'),
    'connect_detect': ('REQ-FUNC-016', 'medium', 'simulation', 'line-state timing'),
    'split': ('REQ-FUNC-017;REQ-FUNC-038;REQ-FUNC-039', 'high', 'simulation', 'multi-microframe transaction sequences with a hub model'),
    'suspend_resume': ('REQ-FUNC-018;REQ-FUNC-019;REQ-FUNC-020;REQ-RESET-002', 'high', 'simulation', 'long idle timers and wake paths'),
    'lpm': ('REQ-FUNC-021', 'medium', 'simulation', 'token sequence and L1 timing'),
    'test_mode': ('REQ-FUNC-022', 'medium', 'simulation', 'selector decode and PHY mode outputs'),
    'dual_role': ('REQ-FUNC-023;REQ-IF-013', 'medium', 'simulation', 'role state machine driven by ID and session'),
    'fifo_mgr': ('REQ-FUNC-026;REQ-FUNC-027;REQ-FUNC-029', 'high', 'formal+simulation', 'pointer and credit logic is bounded control: prove invariants; data in simulation'),
    'zlp_short': ('REQ-FUNC-030;REQ-FUNC-031', 'high', 'simulation', 'transfer-length boundaries'),
    'ocp': ('REQ-FUNC-034;REQ-FUNC-041;REQ-IF-010', 'high', 'formal+simulation', 'filter counter and latch are bounded; PHY write path in simulation'),
    'loopback': ('REQ-FUNC-035', 'low', 'simulation', 'self-contained data loop'),
    'sg_dma': ('REQ-FUNC-036', 'high', 'simulation', 'memory image compared with the model'),
    'ram_parity': ('REQ-FUNC-040', 'high', 'simulation', 'fault injected through the RAM model'),
    'utmi_if': ('REQ-IF-001;REQ-IF-002;REQ-IF-012', 'high', 'simulation', 'protocol assertions on the PHY pins in every test'),
    'ulpi_if': ('REQ-IF-003;REQ-IF-004;REQ-IF-011', 'high', 'simulation', 'protocol assertions and a ULPI PHY BFM'),
    'csr_apb': ('REQ-IF-005;REQ-REG-001', 'high', 'simulation', 'generated register test from the CSR workbook'),
    'axi_master_dma': ('REQ-IF-006;REQ-IF-014;REQ-PERF-001', 'high', 'simulation', 'burst rules by assertion; throughput measured'),
    'axi_slave': ('REQ-IF-007;REQ-IF-009', 'high', 'simulation', 'window access and DMA request handshake'),
    'interrupt': ('REQ-IF-008;REQ-ERR-001', 'high', 'formal+simulation', 'level function of status and enable is provable; sources in simulation'),
    'cdc': ('REQ-CLK-001;REQ-CLK-002;REQ-CLK-003;REQ-REG-002;REQ-REG-003', 'high', 'formal+simulation', 'handshake proven; clock ratios swept in simulation'),
    'reset': ('REQ-RESET-001', 'high', 'formal+simulation', 'synchronizer structure proven; reset during traffic simulated'),
    'param_cfg': ('REQ-FUNC-028;REQ-PARAM-001;REQ-PARAM-002;REQ-PARAM-003;REQ-PARAM-004', 'medium', 'simulation', 'elaboration of each configuration and the configuration check'),
    'babble': ('REQ-ERR-002', 'medium', 'simulation', 'activity past the frame end from the BFM'),
    'process': ('REQ-RTL-001;REQ-VER-001;REQ-VER-002;REQ-VER-003;REQ-DFT-001', 'medium', 'review', 'process requirements without an executable check in this environment'),
}

# Tests: id -> (type, cfg, tier, purpose, combines (list), interaction)
TESTS = {
    't_dev_enum_bulk_dma': ('combined', 'cfg_dev_utmi8_axim', 'smoke',
        'High-speed device enumeration followed by bulk IN and OUT traffic through the AXI master DMA, with PING and NYET flow control.',
        ['hs_chirp', 'dev_token_addr', 'crc', 'data_toggle', 'ping_nyet', 'fifo_mgr', 'axi_master_dma', 'interrupt', 'csr_apb', 'utmi_if', 'cdc'],
        'Chirp, control transfers and bulk data share the FIFO RAM, the register crossing and the DMA; a toggle, credit or crossing fault shows as a data mismatch or a wrong handshake.'),
    't_host_enum_bulk_dma': ('combined', 'cfg_host_utmi8_axim', 'smoke',
        'Host port power, connect, reset with chirp, SOF generation, control enumeration and bulk traffic on several channels.',
        ['connect_detect', 'port_reset', 'hs_chirp', 'host_sof', 'host_sched', 'data_toggle', 'crc', 'fifo_mgr', 'axi_master_dma', 'interrupt', 'utmi_if'],
        'Channels compete for the frame budget while SOF must stay periodic and the DMA refills channel FIFOs; a scheduler or FIFO fault shows as a late SOF, a lost packet or a wrong toggle.'),
    't_dev_iso_int_mix': ('combined', 'cfg_dev_utmi8_axim', 'nightly',
        'High-bandwidth isochronous IN and OUT with interrupt and bulk endpoints active in the same microframes, including ZLP and short-packet transfer ends.',
        ['hb_iso', 'zlp_short', 'packet_size', 'fifo_mgr', 'axi_master_dma', 'turnaround', 'interrupt'],
        'Isochronous packets without retry share RAM regions and DMA bandwidth with retried transfers; starvation or a wrong data PID order shows as iso_inc or a payload mismatch.'),
    't_host_split_poll': ('combined', 'cfg_host_utmi8_axim', 'nightly',
        'Split transactions (bulk, control, interrupt, isochronous) through a hub model while polled interrupt channels run.',
        ['split', 'host_sched', 'host_sof', 'data_toggle', 'fifo_mgr'],
        'Start-split and complete-split phases are spread over microframes and share the periodic schedule with polled channels; a phase or retry-count fault shows as a wrong token in a microframe.'),
    't_dev_suspend_lpm_reset': ('combined', 'cfg_dev_utmi8_axim', 'nightly',
        'Suspend, remote wakeup, host resume, LPM L1 entry and exit, and a bus reset during suspend, with CSR writes in flight.',
        ['suspend_resume', 'lpm', 'hs_chirp', 'cdc', 'reset', 'utmi_if'],
        'Power states change the PHY mode pins while register commands cross clock domains; a lost command or a mode change outside idle shows on the PHY pins.'),
    't_dev_sg_dma': ('combined', 'cfg_dev_utmi8_axim', 'nightly',
        'Scatter-gather descriptor chains for IN and OUT with last and ioc flags, short packets and the address window.',
        ['sg_dma', 'axi_master_dma', 'zlp_short', 'interrupt'],
        'Descriptor fetch, data bursts and status writeback share the AXI channels; an arbitration or length fault shows in the memory image or the descriptor status.'),
    't_dev_axis_win': ('combined', 'cfg_dev_utmi8_axis', 'smoke',
        'Device traffic with the AXI slave windows and the external DMA request and acknowledge handshake, with RREADY and WVALID throttling.',
        ['axi_slave', 'fifo_mgr', 'dev_token_addr', 'data_toggle', 'interrupt'],
        'Bus-side credits and packet events cross to the FIFO manager while the USB side reads and writes the same regions; a credit fault shows as a lost or duplicated row.'),
    't_dev_ulpi_traffic': ('combined', 'cfg_dev_ulpi_axim', 'smoke',
        'Device enumeration and traffic through the ULPI adapter with RX CMD updates, register writes and low power mode.',
        ['ulpi_if', 'dev_token_addr', 'data_toggle', 'turnaround', 'suspend_resume'],
        'RX CMD bytes and register accesses interleave with packet data on the same bus; a turn-around or abort fault shows as a corrupted packet or a late response.'),
    't_host_ulpi_ocp': ('combined', 'cfg_host_ulpi_axim', 'nightly',
        'Host port over ULPI: DrvVbus through PHY registers, over-current trip and re-arm, connect and reset.',
        ['ulpi_if', 'ocp', 'port_reset', 'connect_detect'],
        'The power-off command travels from CLK-BUS to a ULPI register write while the port state machine runs; a lost command leaves VBUS driven.'),
    't_dual_role_switch': ('combined', 'cfg_dual_utmi8_axim', 'nightly',
        'Role selection from the ID pin and the CSR override, host session then device session.',
        ['dual_role', 'port_reset', 'hs_chirp', 'connect_detect', 'dev_token_addr'],
        'Both engines share the link, the FIFO RAM and the PHY mode outputs; a role change before session end shows as two drivers of the mode pins or stale FIFO data.'),
    't_dev_pipe_equiv': ('combined', 'cfg_dev_utmi8_axim_pipe', 'nightly',
        'The enumeration and traffic scenario of t_dev_enum_bulk_dma with every timing option on.',
        ['dev_token_addr', 'data_toggle', 'turnaround', 'fifo_mgr', 'cdc'],
        'Pipeline stages add latency on receive, CRC and register paths; a stage that changes behavior shows as a response outside the turn-around window or a data mismatch.'),
    't_rand_dev_traffic': ('constrained_random', 'cfg_dev_utmi8_axim', 'full',
        'Seeded random legal device traffic on all endpoint types with random packet lengths, gaps, FIFO sizes and AXI backpressure.', [], ''),
    't_rand_host_traffic': ('constrained_random', 'cfg_host_utmi8_axim', 'full',
        'Seeded random host transfers on all channel types against a random-response device model.', [], ''),
    't_rand_dev16_traffic': ('constrained_random', 'cfg_dev_utmi16_axim', 'full',
        'Seeded random device traffic with the 16-bit UTMI+ interface and 64-bit AXI, odd and even packet lengths.', [], ''),
    't_fi_bus_errors': ('fault_injection', 'cfg_dev_utmi8_axim', 'nightly',
        'Corrupted PID, CRC5, CRC16, RXError, truncated packets and missing handshakes injected by the USB BFM in device and host direction.', [], ''),
    't_fi_host_bus_errors': ('fault_injection', 'cfg_host_utmi8_axim', 'nightly',
        'Device model answers with errors, no response, babble and STALL; error counter and channel halt.', [], ''),
    't_fi_axi_err': ('fault_injection', 'cfg_dev_utmi8_axim', 'nightly',
        'AXI memory model returns SLVERR and DECERR on data and descriptor accesses; address outside the DMA window.', [], ''),
    't_fi_ram_parity': ('fault_injection', 'cfg_dev_utmi8_axim', 'nightly',
        'One bit of a FIFO RAM word flipped through the RAM model fault port during IN and OUT packets.', [], ''),
    't_fi_ocp': ('fault_injection', 'cfg_host_utmi8_axim', 'nightly',
        'Over-current input pulses shorter and longer than the filter, with oc_en 0 and 1.', [], ''),
    't_fi_ulpi_abort': ('fault_injection', 'cfg_dev_ulpi_axim', 'nightly',
        'PHY raises dir during a transmit and during a register access.', [], ''),
    't_fi_xq_full': ('fault_injection', 'cfg_dev_utmi8_axim', 'nightly',
        'CSR writes to crossing fields faster than CLK-PHY drains them, with a slow and a stopped CLK-PHY.', [], ''),
    't_fi_csr_access': ('fault_injection', 'cfg_dev_utmi8_axim', 'smoke',
        'APB accesses with partial strobes, unaligned addresses, non-secure protection and unmapped addresses, with i_slverr_en 0 and 1.', [], ''),
    't_fi_axis_err': ('fault_injection', 'cfg_dev_utmi8_axis', 'nightly',
        'AXI slave accesses outside the windows, to an empty region and to a full region.', [], ''),
    't_dir_csr_regs': ('directed', 'cfg_dev_utmi8_axim', 'smoke',
        'Generated register test: reset values, access types and bank counts from the CSR workbook.', [], ''),
    't_dir_timing_ts1': ('directed', 'cfg_dev_utmi8_axim_ts1', 'full',
        'Each millisecond-scale timing requirement measured once with TSCALE = 1.', [], ''),
    't_dir_test_mode': ('directed', 'cfg_dev_utmi8_axim', 'nightly',
        'Each test selector as device, and Test_Force_Enable as host in t_host_enum_bulk_dma.', [], ''),
    't_dir_loopback': ('directed', 'cfg_dev_utmi8_axim', 'nightly',
        'Loopback mode: packets counted good and bad, PHY pins held idle.', [], ''),
    't_dir_reset_midxfer': ('directed', 'cfg_dev_utmi8_axim', 'nightly',
        'Hardware reset of each domain and the CSR software reset in the middle of packets, DMA bursts and register crossings.', [], ''),
    't_dir_clk_ratio': ('directed', 'cfg_dev_utmi8_axim', 'full',
        'The smoke traffic repeated with CLK-BUS from 20 MHz to 200 MHz and random phase.', [], ''),
    't_dir_param_builds': ('directed', 'cfg_dual_utmi8_axim', 'smoke',
        'Elaboration of every configuration of this plan and of illegal parameter sets, with the configuration check result.', [], ''),
    't_perf_iso_in': ('stress', 'cfg_dev_utmi8_axim', 'full',
        'Sustained isochronous IN at three 1024-byte packets per microframe with CLK-BUS at 100 MHz.', [], ''),
    't_fml_fifo': ('formal', 'cfg_unit', 'nightly', 'FIFO manager pointer, credit and region invariants.', [], ''),
    't_fml_cdc_xreg': ('formal', 'cfg_unit', 'nightly', 'Register crossing: no lost, duplicated or torn word; stale update dropped.', [], ''),
    't_fml_crc': ('formal', 'cfg_unit', 'smoke', 'CRC5 and CRC16 equal the bit-serial definition of the polynomial.', [], ''),
    't_fml_ocp_irq_rst': ('formal', 'cfg_unit', 'nightly', 'Over-current filter and latch, interrupt level function, reset synchronizer release.', [], ''),
    't_rev_process': ('directed', 'cfg_review', 'full', 'Recorded review of process requirements.', [], ''),
}

# Checkers: id -> (kind, statement, requirements)
CHECKERS = {
    'chk_usb_pkt': ('scoreboard', 'every packet on the PHY interface (PID, address, endpoint, data PID, handshake) equals the prediction of the Python protocol model', 'REQ-FUNC-001..009, 017, 021, 038, 039'),
    'chk_data_e2e': ('scoreboard', 'payload bytes are equal, in order, once, between the USB side and the AXI memory or window', 'REQ-FUNC-026, 027, 029, 030, 031, 036'),
    'chk_csr_model': ('model compare', 'every CSR read equals the register model: status, counters, xsize, done, error flags', 'REQ-REG-001..003, REQ-FUNC-031..033'),
    'chk_irq': ('scoreboard', 'o_int_usb equals the OR of enabled status bits of the register model, one CLK-BUS cycle later', 'REQ-IF-008, REQ-ERR-001'),
    'chk_timing': ('timing monitor', 'measured intervals at the PHY pins are inside the windows of the requirement', 'REQ-FUNC-006, 010..014, 018..020, 025'),
    'chk_phy_mode': ('monitor', 'XcvrSelect, TermSelect, OpMode and pulldowns equal the table of section 6.3 for the bus state and change only in idle', 'REQ-IF-012, REQ-FUNC-022'),
    'chk_dma_desc': ('scoreboard', 'descriptor status writeback and data pointer equal the model after each packet', 'REQ-FUNC-036, REQ-IF-014'),
    'chk_ocp': ('monitor', 'o_vbus_pwr_en and DrvVbus follow the filter, latch and re-arm rule', 'REQ-FUNC-034, 041, REQ-IF-010'),
    'chk_perf': ('measurement', 'bytes per second and FIFO overflow count over the measurement window', 'REQ-PERF-001'),
    'chk_watchdog': ('timeout', 'every transfer, AXI transaction and CSR access ends within its bound; scoreboards are empty at the end of the test', 'all'),
    'chk_build': ('elaboration', 'each configuration elaborates, absent logic has no ports or registers, the configuration check reports illegal sets', 'REQ-FUNC-028, REQ-PARAM-001..004'),
    'chk_review': ('review record', 'a named reviewer records the decision for a process requirement', 'REQ-RTL-001, REQ-VER-001..003, REQ-DFT-001'),
}

# Assertion modules: id -> (statement, requirement)
ASSERTIONS = {
    'a_utmi_tx': ('TXValid held until TXReady; data stable while not accepted; no transmit while RXActive', 'REQ-IF-001'),
    'a_utmi_w16': ('ValidH and data width follow PARA_USB2_UTMI_W', 'REQ-IF-002'),
    'a_utmi_mode': ('mode pins change only while the bus is idle', 'REQ-IF-012'),
    'a_ulpi_bus': ('stp, dir, nxt turn-around; TX CMD format; no drive while dir is high', 'REQ-IF-003'),
    'a_ulpi_lp': ('low power entry and exit sequence', 'REQ-IF-011'),
    'a_apb': ('PREADY, PSLVERR and PRDATA rules of the APB4 completer', 'REQ-IF-005'),
    'a_axim': ('INCR only, at most 16 beats, no 4 KB crossing, full-width beats, valid stable until ready', 'REQ-IF-006'),
    'a_axim_win': ('no address outside the DMA window when win_en is 1', 'REQ-IF-014'),
    'a_axis': ('response rules of the AXI slave, SLVERR outside windows, valid stable until ready', 'REQ-IF-007'),
    'a_dmareq': ('o_dma_req held until the burst ends', 'REQ-IF-009'),
    'a_irq_level': ('o_int_usb is the registered OR of enabled status bits', 'REQ-IF-008'),
    'a_fifo_inv': ('no read of unwritten data, no overwrite of unread data, counters within the region', 'REQ-FUNC-027'),
    'a_fifo_dbuf': ('the two packet buffers swap only at a packet end', 'REQ-FUNC-029'),
    'a_xreg_word': ('a register crosses as one whole word, once, in order', 'REQ-CLK-003'),
    'a_xreg_tag': ('an update with a stale generation tag is dropped', 'REQ-REG-003'),
    'a_xreg_free': ('xq_free equals the free entries; a write at 0 is dropped and sets xq_ovf', 'REQ-REG-002'),
    'a_cdc_struct': ('every crossing uses a structure of section 7.2', 'REQ-CLK-002'),
    'a_crc5': ('CRC5 equals the bit-serial polynomial definition', 'REQ-FUNC-003'),
    'a_crc16': ('CRC16 equals the bit-serial polynomial definition', 'REQ-FUNC-003'),
    'a_ocp_filter': ('power drops within 2 cycles after 16 low cycles and stays off until re-armed', 'REQ-FUNC-034'),
    'a_rst_sync': ('asynchronous assertion, synchronous release in each domain', 'REQ-RESET-001'),
}

# Failure modes: id -> (feature, failure mode, trigger, expected detection)
FM = {
    'FM-001': ('dev_token_addr', 'device answers a token for another address or an uninitialized endpoint', 'tokens with wrong address or endpoint between valid ones', 'no response'),
    'FM-002': ('dev_token_addr', 'packet with bad PID check bits or an undefined PID is accepted', 'corrupted PID byte', 'packet ignored, PID error status'),
    'FM-003': ('crc', 'packet with a CRC error is accepted, or a good CRC is rejected', 'one flipped bit in token or data', 'no handshake, CRC error status; good packets pass'),
    'FM-004': ('data_toggle', 'toggle advances after a lost handshake, or duplicate data is delivered twice', 'drop ACK; resend with same toggle', 'duplicate discarded and ACKed; toggle unchanged on retry'),
    'FM-005': ('data_toggle', 'SETUP does not resynchronize the toggle', 'SETUP after a desynchronized state', 'DATA0 accepted, next data stage DATA1'),
    'FM-006': ('ping_nyet', 'ACK instead of NYET when no room is left, or NAK when room exists', 'OUT packets while the FIFO has exactly one or zero packet of room', 'NYET, NAK and PING answers per the model'),
    'FM-007': ('turnaround', 'response earlier than the minimum or later than the maximum gap', 'all response types in 8-bit, 16-bit and ULPI builds, with pipeline options', 'measured gap inside the window'),
    'FM-008': ('turnaround', 'timeout declared too early or too late', 'response delayed to each edge of the window', 'transaction error only beyond the window'),
    'FM-009': ('packet_size', 'packet longer than the maximum packet size or 1024 bytes is stored', 'max+1 bytes', 'babble or data error, no FIFO corruption'),
    'FM-010': ('hb_iso', 'wrong data PID order in a microframe', 'one, two and three transactions per microframe', 'DATA0/1/2/MDATA order of the model'),
    'FM-011': ('hb_iso', 'missing iso_inc when data is not ready or a packet has an error', 'IN token with empty FIFO; corrupted OUT', 'iso_inc set, no retry'),
    'FM-012': ('host_sof', 'SOF interval drifts or the frame number does not roll over', 'run past frame 7FFh; suspend and resume', 'interval and number sequence'),
    'FM-013': ('port_reset', 'reset shorter than the minimum, or traffic before recovery', 'port reset command', 'SE0 duration and recovery gap'),
    'FM-014': ('hs_chirp', 'high-speed selected without a valid chirp sequence, or full-speed fallback missed', 'chirp absent, short, or fewer than three K-J pairs', 'speed status equals the model'),
    'FM-015': ('host_sched', 'transaction started that cannot finish before SOF', 'long packets queued late in the frame', 'no transmission in the guard time'),
    'FM-016': ('host_sched', 'periodic channel served after non-periodic, or poll interval wrong', 'many channels ready together', 'order and interval of the model; poll_miss'),
    'FM-017': ('connect_detect', 'disconnect not detected in high-speed', 'HostDisconnect at SOF', 'port status change, switch to full-speed'),
    'FM-018': ('split', 'complete-split in the wrong microframe or wrong retry count', 'NYET, NAK and ERR from the hub model', 'token sequence of the model'),
    'FM-019': ('suspend_resume', 'suspend entered early, or resume signalling outside its window', 'idle of 2.9 ms and 3.1 ms; remote wakeup', 'state and timing'),
    'FM-020': ('suspend_resume', 'bus reset during suspend does not wake the device', 'SE0 during suspend', 'Default state'),
    'FM-021': ('lpm', 'LPM token accepted with LPM disabled or an invalid link state', 'EXT token with each attribute value', 'handshake of the model'),
    'FM-022': ('test_mode', 'invalid selector enters a test mode', 'selector values 0 to 255', 'request error, no mode change'),
    'FM-023': ('dual_role', 'role changes during a session', 'ID change while connected', 'role held until session end'),
    'FM-024': ('fifo_mgr', 'read of unwritten data or overwrite of unread data', 'full and empty regions with simultaneous access', 'NAK or deferral; proof of the invariant'),
    'FM-025': ('fifo_mgr', 'double-buffer swap in the middle of a packet', 'back-to-back packets with DMA backpressure', 'buf_cur and data order'),
    'FM-026': ('fifo_mgr', 'packet aborted on the bus leaves partial data in the region', 'CRC error or cancel after bytes were written', 'region pointers restored'),
    'FM-027': ('zlp_short', 'missing or extra zero-length packet at a transfer end', 'sizes 0, max-1, max, 2*max', 'packet sequence of the model'),
    'FM-028': ('zlp_short', 'xsize wrong after a short packet', 'short packet in the first, middle and last position', 'xsize and done flag'),
    'FM-029': ('ocp', 'power stays on after an over-current, or restores without software', 'pulses of 15, 16 and 17 cycles; clear without vbus_drv', 'o_vbus_pwr_en, ocur, oc_act'),
    'FM-030': ('sg_dma', 'descriptor status or pointer wrong', 'chains with last, ioc, short packets', 'memory image and descriptor words'),
    'FM-031': ('axi_master_dma', 'burst crosses 4 KB, exceeds 16 beats or is not INCR', 'buffers at every offset near a 4 KB boundary', 'assertion and data check'),
    'FM-032': ('axi_master_dma', 'AXI error response not reported, or transfer continues', 'SLVERR and DECERR on each channel', 'axi_err, dma_err, endpoint stopped'),
    'FM-033': ('axi_master_dma', 'access outside the DMA window', 'buffer or descriptor below base or above limit', 'no AXI access to the address, dma_err'),
    'FM-034': ('ram_parity', 'parity error not detected or packet still acknowledged', 'bit flip in a stored word', 'ram_par, no handshake (IN) or NAK (OUT)'),
    'FM-035': ('utmi_if', 'mode pins change while a packet is on the bus', 'speed and power state changes during traffic', 'assertion a_utmi_mode'),
    'FM-036': ('ulpi_if', 'packet corrupted by an RX CMD or a register access', 'RX CMD between and inside packets; register write requests during traffic', 'packet scoreboard'),
    'FM-037': ('ulpi_if', 'abort by dir not recovered', 'dir high during transmit and register access', 'retry or error status, bus rules hold'),
    'FM-038': ('csr_apb', 'wrong reset value, access type or bank count', 'generated walk over the workbook', 'register model'),
    'FM-039': ('csr_apb', 'error access changes a register or gives the wrong response', 'partial strobe, unaligned, protected, unmapped', 'PSLVERR rule of section 11.4'),
    'FM-040': ('axi_slave', 'row lost or duplicated under RREADY or WVALID throttling', 'random throttling on both channels', 'data scoreboard'),
    'FM-041': ('axi_slave', 'access outside a window completes without error', 'addresses outside every window; empty and full region', 'SLVERR, axi_err'),
    'FM-042': ('interrupt', 'interrupt output not level, or set by a masked source', 'each source with enable 0 and 1; clear while a second source is pending', 'o_int_usb'),
    'FM-043': ('cdc', 'register word lost, duplicated or torn across domains', 'write bursts at every clock ratio; command FIFO full', 'register model and proof'),
    'FM-044': ('cdc', 'stale hardware update overwrites a newer software write', 'software write while an update is in flight', 'software value kept'),
    'FM-045': ('reset', 'state not returned to reset value, or a glitch on outputs at release', 'reset in the middle of each activity', 'reset values, bus idle'),
    'FM-046': ('param_cfg', 'logic of a disabled role or option present, or bank count wrong', 'each configuration', 'elaboration report'),
    'FM-047': ('babble', 'host keeps transmitting or does not report babble', 'device model transmits past the frame end', 'babble status, transmission stopped'),
    'FM-048': ('loopback', 'loopback drives the PHY pins or miscounts packets', 'good and corrupted packets in loopback', 'pins idle, counters'),
    'FM-049': ('axi_master_dma', 'FIFO overflow at the required isochronous rate', 'three 1024-byte packets per microframe', 'no overflow, measured rate'),
    'FM-050': ('host_sof', 'SOF not phase-locked after suspend or L1', 'selective suspend and L1 of several lengths', 'SOF phase'),
}

# Vplan rows: (req, feature, dimension, scenario, stimulus, checkers, bins, assertions, tests, fm, notes)
R = []


def row(req, feature, dim, scenario, stimulus, chk, bins, asserts, test, fm='', notes=''):
    R.append((req, feature, dim, scenario, stimulus, chk, bins, asserts, test, fm, notes))


row('REQ-FUNC-001', 'dev_token_addr', 'normal', 'Address 0 after reset, SET_ADDRESS, tokens for own and other addresses and endpoints', 'USB host BFM sends tokens with every address class', 'chk_usb_pkt', 'cg_tok_addr.own;cg_tok_addr.other;cg_tok_addr.uninit_ep', '', 't_dev_enum_bulk_dma', 'FM-001')
row('REQ-FUNC-002', 'dev_token_addr', 'error', 'Bad PID check bits, undefined PID, PID of an unsupported direction', 'BFM corrupts the PID byte', 'chk_usb_pkt;chk_csr_model', 'cg_pid.bad_check;cg_pid.undefined;cg_pid.unsupported', '', 't_fi_bus_errors', 'FM-002')
row('REQ-FUNC-003', 'crc', 'normal', 'CRC5 and CRC16 generated and checked on every packet of the traffic', 'all packet types', 'chk_usb_pkt', 'cg_crc.good5;cg_crc.good16', '', 't_dev_enum_bulk_dma', 'FM-003')
row('REQ-FUNC-003', 'crc', 'error', 'One-bit CRC errors in token and data packets, both directions', 'BFM flips one bit', 'chk_usb_pkt;chk_csr_model', 'cg_crc.bad5;cg_crc.bad16', '', 't_fi_bus_errors', 'FM-003')
row('REQ-FUNC-003', 'crc', 'boundary', 'CRC functions equal the bit-serial polynomial for every input', 'formal equivalence with a bit-serial reference', 'chk_watchdog', '', 'a_crc5;a_crc16', 't_fml_crc', 'FM-003')
row('REQ-FUNC-004', 'data_toggle', 'normal', 'Toggle sequence on control, bulk and interrupt transfers in both directions', 'transfers of several packets', 'chk_usb_pkt;chk_data_e2e', 'cg_toggle.d0;cg_toggle.d1;cg_toggle.setup', '', 't_dev_enum_bulk_dma;t_host_enum_bulk_dma', 'FM-005')
row('REQ-FUNC-004', 'data_toggle', 'recovery', 'Lost handshake and retried packet with the same toggle', 'BFM drops ACK and repeats', 'chk_usb_pkt;chk_data_e2e', 'cg_toggle.retry_same;cg_toggle.dup_discard', '', 't_fi_bus_errors;t_fi_host_bus_errors', 'FM-004')
row('REQ-FUNC-005', 'ping_nyet', 'boundary', 'OUT and PING with room for two, one and zero maximum packets', 'BFM fills the endpoint while the DMA is throttled', 'chk_usb_pkt', 'cg_flow.ack;cg_flow.nyet;cg_flow.nak;cg_flow.ping_ack;cg_flow.ping_nak', '', 't_dev_enum_bulk_dma', 'FM-006')
row('REQ-FUNC-006', 'turnaround', 'boundary', 'Device response gap for every response type', 'all handshakes and data responses', 'chk_timing', 'cg_gap_dev.min;cg_gap_dev.max', '', 't_dev_enum_bulk_dma;t_dev_pipe_equiv;t_dev_ulpi_traffic', 'FM-007')
row('REQ-FUNC-007', 'dev_token_addr', 'normal', 'Endpoint 0 present in every build; other endpoints follow the parameter', 'control transfer on EP0; tokens for each configured endpoint', 'chk_usb_pkt;chk_build', 'cg_ep.ep0;cg_ep.last', '', 't_dev_enum_bulk_dma;t_dir_param_builds', 'FM-046')
row('REQ-FUNC-008', 'packet_size', 'boundary', 'Data field of 0, 1, max-1, max and max+1 bytes; 1024 and 1025 bytes', 'BFM and DUT transfers of each length', 'chk_usb_pkt;chk_data_e2e', 'cg_len.zero;cg_len.one;cg_len.max;cg_len.over', '', 't_dev_iso_int_mix;t_rand_dev_traffic', 'FM-009')
row('REQ-FUNC-009', 'hb_iso', 'normal', 'One, two and three isochronous transactions per microframe, IN and OUT', 'mult 1 to 3', 'chk_usb_pkt;chk_data_e2e', 'cg_iso.m1;cg_iso.m2;cg_iso.m3;cg_iso.mdata', '', 't_dev_iso_int_mix', 'FM-010')
row('REQ-FUNC-010', 'host_sof', 'normal', 'SOF interval and frame number including the roll-over at 7FFh, full-speed and high-speed', 'host runs more than 2048 frames at TSCALE', 'chk_timing;chk_usb_pkt', 'cg_sof.hs;cg_sof.fs;cg_sof.rollover', '', 't_host_enum_bulk_dma', 'FM-012')
row('REQ-FUNC-011', 'port_reset', 'normal', 'Port reset duration and recovery before the first request', 'port reset command', 'chk_timing', 'cg_prst.duration;cg_prst.recovery', '', 't_host_enum_bulk_dma;t_dir_timing_ts1', 'FM-013')
row('REQ-FUNC-012', 'hs_chirp', 'normal', 'Host detects the device chirp and answers with K-J pairs inside the timing windows', 'device model chirps at each edge of its window', 'chk_timing;chk_phy_mode', 'cg_chirp_h.detect;cg_chirp_h.kj;cg_chirp_h.end', '', 't_host_enum_bulk_dma;t_dir_timing_ts1', 'FM-014')
row('REQ-FUNC-013', 'hs_chirp', 'boundary', 'Device chirp length and reaction to a complete, incomplete and missing host sequence', 'host BFM sends 0, 2 and 3 K-J pairs', 'chk_timing;chk_csr_model', 'cg_chirp_d.hs;cg_chirp_d.fs_fallback;cg_chirp_d.short', '', 't_dev_enum_bulk_dma;t_dev_suspend_lpm_reset;t_dir_timing_ts1', 'FM-014')
row('REQ-FUNC-014', 'turnaround', 'boundary', 'Host inter-packet gaps in each speed', 'host transactions of every type', 'chk_timing', 'cg_gap_host.min;cg_gap_host.b2b;cg_gap_host.max', '', 't_host_enum_bulk_dma', 'FM-007')
row('REQ-FUNC-015', 'host_sched', 'concurrency', 'Periodic before non-periodic, frame budget and no transaction across SOF', 'eight channels ready in the same microframe with long packets', 'chk_usb_pkt;chk_timing', 'cg_sched.periodic_first;cg_sched.budget;cg_sched.guard', '', 't_host_enum_bulk_dma;t_host_split_poll', 'FM-015;FM-016')
row('REQ-FUNC-016', 'connect_detect', 'normal', 'Connect and disconnect in full-speed, low-speed and high-speed', 'device model attaches and detaches', 'chk_csr_model;chk_timing', 'cg_conn.fs;cg_conn.ls;cg_conn.hs_disc', '', 't_host_enum_bulk_dma;t_host_ulpi_ocp', 'FM-017')
row('REQ-FUNC-017', 'split', 'normal', 'Start-split and complete-split tokens for each transfer type, low-speed preamble path', 'hub model with full-speed and low-speed devices', 'chk_usb_pkt', 'cg_split.ss;cg_split.cs;cg_split.nyet;cg_split.err', '', 't_host_split_poll', 'FM-018')
row('REQ-FUNC-018', 'suspend_resume', 'boundary', 'Suspend after 3 ms of idle and high-speed reversion to full-speed', 'idle of 2.9 ms and 3.1 ms (scaled) and at TSCALE=1', 'chk_timing;chk_phy_mode', 'cg_susp.enter;cg_susp.no_enter;cg_susp.hs_revert', '', 't_dev_suspend_lpm_reset;t_dir_timing_ts1', 'FM-019')
row('REQ-FUNC-019', 'suspend_resume', 'normal', 'Remote wakeup after 5 ms idle, resume length', 'software requests wakeup at several idle times', 'chk_timing', 'cg_wake.early_req;cg_wake.drive', '', 't_dev_suspend_lpm_reset', 'FM-019')
row('REQ-FUNC-020', 'suspend_resume', 'normal', 'Host resume length, end of resume per speed, SOF within 3 ms', 'port suspend and resume commands', 'chk_timing', 'cg_hres.fs;cg_hres.hs;cg_hres.sof', '', 't_host_enum_bulk_dma;t_dir_timing_ts1', 'FM-019')
row('REQ-FUNC-021', 'lpm', 'normal', 'LPM token decode, handshake, L1 entry and exit, as device and as host', 'EXT and LPM tokens with each attribute', 'chk_usb_pkt;chk_timing', 'cg_lpm.ack;cg_lpm.nyet;cg_lpm.stall;cg_lpm.l1_exit', '', 't_dev_suspend_lpm_reset;t_host_enum_bulk_dma', 'FM-021')
row('REQ-FUNC-022', 'test_mode', 'normal', 'Each test selector and invalid selectors', 'SetFeature(TEST_MODE) with selectors 0 to 5 and invalid values', 'chk_phy_mode;chk_usb_pkt', 'cg_test.j;cg_test.k;cg_test.se0nak;cg_test.packet;cg_test.force_en;cg_test.invalid', '', 't_dir_test_mode', 'FM-022', 'combine_na=test modes stop normal traffic by definition')
row('REQ-FUNC-023', 'dual_role', 'normal', 'Role from the ID indication and from the CSR override; change only after session end', 'ID changes idle and during a session', 'chk_csr_model;chk_phy_mode', 'cg_role.host;cg_role.dev;cg_role.override;cg_role.held', '', 't_dual_role_switch', 'FM-023')
row('REQ-FUNC-024', 'hs_chirp', 'normal', 'Speed after reset equals the chirp result', 'resets with and without a chirp answer', 'chk_csr_model', 'cg_speed.hs;cg_speed.fs', '', 't_dev_enum_bulk_dma;t_dual_role_switch', 'FM-014')
row('REQ-FUNC-025', 'turnaround', 'boundary', 'Response timeout window in each speed and interface width', 'response at 735, 737, 815 and 817 bit times', 'chk_timing;chk_csr_model', 'cg_tmo.inside;cg_tmo.early_edge;cg_tmo.late_edge', '', 't_fi_bus_errors;t_fi_host_bus_errors', 'FM-008')
row('REQ-FUNC-026', 'fifo_mgr', 'normal', 'Regions programmed by software at several sizes and positions', 'random legal region maps', 'chk_data_e2e', 'cg_fifo.map_min;cg_fifo.map_max', '', 't_rand_dev_traffic;t_rand_host_traffic', 'FM-024')
row('REQ-FUNC-027', 'fifo_mgr', 'backpressure', 'Full and empty regions with simultaneous bus and USB access', 'DMA throttled and released while packets arrive', 'chk_data_e2e;chk_usb_pkt', 'cg_fifo.full_nak;cg_fifo.empty_nak;cg_fifo.abort_restore', '', 't_dev_enum_bulk_dma;t_dev_axis_win', 'FM-024;FM-026')
row('REQ-FUNC-027', 'fifo_mgr', 'boundary', 'Pointer, counter and credit invariants of the FIFO manager', 'formal proof on m_usb2_fifo with free inputs under interface assumptions', 'chk_watchdog', '', 'a_fifo_inv', 't_fml_fifo', 'FM-024')
row('REQ-FUNC-028', 'param_cfg', 'normal', 'Endpoint and channel counts follow the parameters', 'elaborate every configuration; access the last bank entry', 'chk_build;chk_csr_model', 'cg_build.cfg_each', '', 't_dir_param_builds', 'FM-046', 'combine_na=elaboration check, not a run-time function')
row('REQ-FUNC-029', 'fifo_mgr', 'concurrency', 'Double-buffer fill and drain with swap at packet end', 'back-to-back packets with dbuf 0 and 1', 'chk_data_e2e;chk_csr_model', 'cg_dbuf.swap;cg_dbuf.both_full', 'a_fifo_dbuf', 't_dev_iso_int_mix;t_fml_fifo', 'FM-025')
row('REQ-FUNC-030', 'zlp_short', 'boundary', 'Zero-length packet after a transfer that is a multiple of the maximum packet size', 'sizes 0, max, 2*max with zlp_en 0 and 1', 'chk_usb_pkt', 'cg_zlp.sent;cg_zlp.not_sent', '', 't_dev_iso_int_mix;t_dev_sg_dma', 'FM-027')
row('REQ-FUNC-031', 'zlp_short', 'boundary', 'Transfer ends at a short packet; xsize holds the remainder', 'short packet first, middle and last', 'chk_csr_model;chk_data_e2e', 'cg_short.first;cg_short.mid;cg_short.last', '', 't_dev_iso_int_mix;t_dev_sg_dma', 'FM-028')
row('REQ-FUNC-032', 'host_sched', 'normal', 'Polled channels at each interval, NAK retry, re-arm and poll_miss', 'intervals 1, 2, 8 and the maximum', 'chk_usb_pkt;chk_csr_model', 'cg_poll.int1;cg_poll.int_max;cg_poll.rearm;cg_poll.miss', '', 't_host_split_poll', 'FM-016')
row('REQ-FUNC-033', 'hb_iso', 'error', 'iso_inc for IN without data, OUT with error and a host transfer not done in its microframe', 'empty FIFO at the token; corrupted packet', 'chk_csr_model;chk_irq', 'cg_isoinc.in_nodata;cg_isoinc.out_err;cg_isoinc.host_late', '', 't_dev_iso_int_mix;t_fi_host_bus_errors', 'FM-011')
row('REQ-FUNC-034', 'ocp', 'error', 'Over-current pulses around the filter length; power off, latch and re-arm', 'pulses of 15, 16, 17 cycles; oc_en 0 and 1', 'chk_ocp;chk_irq', 'cg_ocp.short;cg_ocp.trip;cg_ocp.rearm;cg_ocp.disabled', 'a_ocp_filter', 't_fi_ocp;t_fml_ocp_irq_rst', 'FM-029')
row('REQ-FUNC-035', 'loopback', 'normal', 'Loopback of good and corrupted packets; PHY pins idle', 'lpbk set, packets from the transmit path', 'chk_csr_model;chk_phy_mode', 'cg_lpbk.good;cg_lpbk.bad', '', 't_dir_loopback', 'FM-048', 'combine_na=loopback isolates the PHY, no bus traffic can run with it')
row('REQ-FUNC-036', 'sg_dma', 'normal', 'Descriptor chains for IN and OUT with status writeback', 'chains of 1 to 16 descriptors, last and ioc', 'chk_dma_desc;chk_data_e2e', 'cg_sg.single;cg_sg.chain;cg_sg.short;cg_sg.ioc', '', 't_dev_sg_dma', 'FM-030')
row('REQ-FUNC-037', 'host_sof', 'recovery', 'SOF phase kept through selective suspend and L1', 'suspend and L1 of several lengths', 'chk_timing', 'cg_sofphase.suspend;cg_sofphase.l1', '', 't_host_enum_bulk_dma', 'FM-050')
row('REQ-FUNC-038', 'split', 'boundary', 'Periodic split timing: start-split and complete-split microframes', 'interrupt and isochronous IN through the hub model in each microframe position', 'chk_usb_pkt', 'cg_psplit.uf_each;cg_psplit.third_cs', '', 't_host_split_poll', 'FM-018')
row('REQ-FUNC-039', 'split', 'recovery', 'Bulk and control split retries and the three-error limit', 'hub model answers NAK, NYET, ERR and nothing', 'chk_usb_pkt;chk_csr_model', 'cg_bsplit.ss_retry;cg_bsplit.cs_retry;cg_bsplit.err3', '', 't_host_split_poll;t_fi_host_bus_errors', 'FM-018')
row('REQ-FUNC-040', 'ram_parity', 'error', 'Parity error on a read during IN and OUT packets', 'RAM model flips one stored bit', 'chk_usb_pkt;chk_csr_model;chk_irq', 'cg_par.in;cg_par.out', '', 't_fi_ram_parity', 'FM-034', 'combine_na=fault injection test')
row('REQ-FUNC-041', 'ocp', 'normal', 'DrvVbus follows the power-off state: UTMI+ pin and ULPI register write', 'over-current and software power commands', 'chk_ocp', 'cg_drvvbus.utmi;cg_drvvbus.ulpi', '', 't_fi_ocp;t_host_ulpi_ocp', 'FM-029')
row('REQ-IF-001', 'utmi_if', 'normal', 'UTMI+ link rules on every packet of every UTMI+ test', 'all traffic', 'chk_watchdog', 'cg_utmi.tx_wait;cg_utmi.rx_gap', 'a_utmi_tx', 't_dev_enum_bulk_dma;t_host_enum_bulk_dma', 'FM-035')
row('REQ-IF-002', 'utmi_if', 'boundary', '16-bit interface with odd and even packet lengths', 'random lengths in the 16-bit configuration', 'chk_usb_pkt;chk_data_e2e', 'cg_utmi16.odd;cg_utmi16.even', 'a_utmi_w16', 't_rand_dev16_traffic', 'FM-035')
row('REQ-IF-003', 'ulpi_if', 'normal', 'ULPI bus rules: TX CMD, RX CMD, register read and write', 'traffic with RX CMD updates and register accesses', 'chk_usb_pkt', 'cg_ulpi.rxcmd_idle;cg_ulpi.rxcmd_in_pkt;cg_ulpi.regwr;cg_ulpi.regrd', 'a_ulpi_bus', 't_dev_ulpi_traffic;t_host_ulpi_ocp', 'FM-036')
row('REQ-IF-003', 'ulpi_if', 'error', 'Abort by dir during transmit and register access', 'PHY BFM raises dir', 'chk_usb_pkt;chk_csr_model', 'cg_ulpi.abort_tx;cg_ulpi.abort_reg', 'a_ulpi_bus', 't_fi_ulpi_abort', 'FM-037')
row('REQ-IF-004', 'ulpi_if', 'boundary', 'Response timing through the ULPI adapter', 'all response types with PHY pipeline delay at its limits', 'chk_timing', 'cg_gap_ulpi.min;cg_gap_ulpi.max', '', 't_dev_ulpi_traffic', 'FM-007')
row('REQ-IF-005', 'csr_apb', 'normal', 'APB read and write of every register with random wait between accesses', 'generated register walk', 'chk_csr_model', 'cg_apb.read;cg_apb.write', 'a_apb', 't_dir_csr_regs;t_dev_enum_bulk_dma', 'FM-038')
row('REQ-IF-005', 'csr_apb', 'error', 'Error accesses of section 11.4 with i_slverr_en and i_protect_en 0 and 1', 'partial strobe, unaligned, protected and unmapped accesses', 'chk_csr_model', 'cg_apberr.strobe;cg_apberr.align;cg_apberr.prot;cg_apberr.unmapped;cg_apberr.strobe_noerr', 'a_apb', 't_fi_csr_access', 'FM-039')
row('REQ-IF-006', 'axi_master_dma', 'boundary', 'Burst shape at every buffer offset near a 4 KB boundary, with backpressure', 'random buffer addresses and lengths; random ready', 'chk_data_e2e', 'cg_axim.len1;cg_axim.len16;cg_axim.cross4k;cg_axim.bp', 'a_axim', 't_dev_enum_bulk_dma;t_rand_dev_traffic', 'FM-031')
row('REQ-IF-006', 'axi_master_dma', 'error', 'BRESP and RRESP errors on data accesses', 'memory model returns SLVERR and DECERR', 'chk_csr_model;chk_irq', 'cg_aximerr.bresp;cg_aximerr.rresp', 'a_axim', 't_fi_axi_err', 'FM-032')
row('REQ-IF-007', 'axi_slave', 'backpressure', 'FIXED and INCR window access with throttled ready and valid', 'random bursts of 1 to 16 beats', 'chk_data_e2e', 'cg_axis.fixed;cg_axis.incr;cg_axis.len16;cg_axis.bp', 'a_axis', 't_dev_axis_win', 'FM-040')
row('REQ-IF-007', 'axi_slave', 'error', 'Access outside the windows, to an empty and to a full region', 'directed addresses', 'chk_csr_model', 'cg_axiserr.outside;cg_axiserr.empty;cg_axiserr.full', 'a_axis', 't_fi_axis_err', 'FM-041')
row('REQ-IF-008', 'interrupt', 'normal', 'Each interrupt source with enable 0 and 1; second source pending at clear', 'all tests raise and clear sources', 'chk_irq', 'cg_irq.each_source;cg_irq.masked;cg_irq.two_pending', 'a_irq_level', 't_dev_enum_bulk_dma;t_host_enum_bulk_dma;t_fml_ocp_irq_rst', 'FM-042')
row('REQ-IF-009', 'axi_slave', 'normal', 'DMA request raised at the threshold and held until the burst ends', 'external DMA model with random acknowledge delay', 'chk_data_e2e', 'cg_dmareq.rise;cg_dmareq.hold', 'a_dmareq', 't_dev_axis_win', 'FM-040')
row('REQ-IF-010', 'ocp', 'normal', 'Asynchronous over-current input synchronized and filtered; registered power output', 'input edges at random phase to CLK-BUS', 'chk_ocp', 'cg_ocin.async_edge', 'a_ocp_filter', 't_fi_ocp', 'FM-029')
row('REQ-IF-011', 'ulpi_if', 'normal', 'ULPI low power entry and exit with the PHY clock stopped', 'suspend and wake through the PHY BFM', 'chk_csr_model', 'cg_ulpilp.enter;cg_ulpilp.exit', 'a_ulpi_lp', 't_dev_ulpi_traffic', 'FM-036')
row('REQ-IF-012', 'utmi_if', 'normal', 'Mode pins for each bus state, changed only in idle', 'every speed and power state of the tests', 'chk_phy_mode', 'cg_mode.each_state', 'a_utmi_mode', 't_dev_suspend_lpm_reset;t_host_enum_bulk_dma', 'FM-035')
row('REQ-IF-013', 'dual_role', 'normal', 'ID from the RX CMD byte after the IdPullup delay in ULPI builds', 'PHY BFM reports ID in RX CMD', 'chk_csr_model', 'cg_ulpi_id.a;cg_ulpi_id.b', '', 't_host_ulpi_ocp', 'FM-023')
row('REQ-IF-014', 'axi_master_dma', 'error', 'Buffer and descriptor addresses outside the DMA window', 'addresses below base, above limit and straddling', 'chk_dma_desc;chk_csr_model', 'cg_win.below;cg_win.above;cg_win.straddle', 'a_axim_win', 't_fi_axi_err;t_dev_sg_dma', 'FM-033')
row('REQ-CLK-001', 'cdc', 'boundary', 'Traffic with CLK-BUS from 20 MHz to 200 MHz at random phase, CLK-PHY 60 and 30 MHz', 'smoke scenario at each ratio', 'chk_data_e2e;chk_csr_model', 'cg_ratio.slow_bus;cg_ratio.equal;cg_ratio.fast_bus', '', 't_dir_clk_ratio;t_dev_enum_bulk_dma', 'FM-043')
row('REQ-CLK-002', 'cdc', 'normal', 'Every crossing uses a listed structure', 'structural check of the crossing list against section 7.2', 'chk_review', '', 'a_cdc_struct', 't_fml_cdc_xreg', 'FM-043', 'structural review supported by the CDC list; a commercial CDC tool is not available')
row('REQ-CLK-003', 'cdc', 'concurrency', 'Register words cross whole, once and in order while both domains are active', 'formal proof on m_usb2_xreg with independent clocks; CSR write bursts in simulation', 'chk_csr_model', 'cg_xreg.burst;cg_xreg.both_dir', 'a_xreg_word', 't_fml_cdc_xreg;t_dev_suspend_lpm_reset', 'FM-043')
row('REQ-RESET-001', 'reset', 'reset', 'Hardware reset of each domain and software reset in the middle of each activity', 'reset during a packet, a DMA burst, a register crossing', 'chk_csr_model;chk_usb_pkt', 'cg_rst.in_pkt;cg_rst.in_dma;cg_rst.in_xreg;cg_rst.soft', 'a_rst_sync', 't_dir_reset_midxfer;t_fml_ocp_irq_rst;t_dev_suspend_lpm_reset', 'FM-045')
row('REQ-RESET-002', 'suspend_resume', 'reset', 'Bus reset during suspend returns the device to Default', 'SE0 while suspended', 'chk_csr_model;chk_timing', 'cg_susp.reset_wake', '', 't_dev_suspend_lpm_reset', 'FM-020')
row('REQ-PARAM-001', 'param_cfg', 'error', 'Illegal parameter sets are reported by the configuration check', 'elaborate one illegal value per parameter', 'chk_build', 'cg_build.illegal_each', '', 't_dir_param_builds', 'FM-046')
row('REQ-PARAM-002', 'param_cfg', 'normal', 'Logic of a disabled role or option is absent', 'compare elaborated hierarchy and register banks per configuration', 'chk_build', 'cg_build.role0;cg_build.role1;cg_build.opt_off', '', 't_dir_param_builds', 'FM-046')
row('REQ-PARAM-003', 'param_cfg', 'normal', 'CSR bank counts derived from the parameters', 'read the last entry and the entry after it for each bank', 'chk_build;chk_csr_model', 'cg_bank.last;cg_bank.beyond', '', 't_dir_param_builds;t_dir_csr_regs', 'FM-046')
row('REQ-PARAM-004', 'param_cfg', 'boundary', 'FIFO depth below the sum of the minimum regions is reported', 'depth one word below and at the minimum', 'chk_build', 'cg_build.depth_min;cg_build.depth_below', '', 't_dir_param_builds', 'FM-046')
row('REQ-REG-001', 'csr_apb', 'normal', 'Register map equals the CSR workbook; version register at 0x0', 'generated walk: reset value, access type, reserved bits', 'chk_csr_model', 'cg_reg.reset_each;cg_reg.access_each', 'a_apb', 't_dir_csr_regs', 'FM-038')
row('REQ-REG-002', 'cdc', 'backpressure', 'xq_free count; write dropped and xq_ovf set when the command FIFO is full', 'write bursts with slow and stopped CLK-PHY', 'chk_csr_model', 'cg_xq.free0;cg_xq.ovf', 'a_xreg_free', 't_fi_xq_full;t_fml_cdc_xreg', 'FM-043')
row('REQ-REG-003', 'cdc', 'concurrency', 'Stale hardware update dropped when software wrote the register meanwhile', 'software write at every phase of an update in flight', 'chk_csr_model', 'cg_tag.stale_drop;cg_tag.fresh_apply', 'a_xreg_tag', 't_fml_cdc_xreg;t_dev_suspend_lpm_reset', 'FM-044')
row('REQ-ERR-001', 'interrupt', 'error', 'Every error event of the list reaches the interrupt status', 'each error injected once per direction', 'chk_csr_model;chk_irq', 'cg_err.pid;cg_err.crc;cg_err.stuff;cg_err.timeout;cg_err.babble;cg_err.fifo;cg_err.axi;cg_err.dma', '', 't_fi_bus_errors;t_fi_host_bus_errors;t_fi_axi_err', 'FM-042')
row('REQ-ERR-002', 'babble', 'error', 'Babble in high-speed and full-speed: host stops and reports', 'device model transmits past the frame end', 'chk_usb_pkt;chk_csr_model', 'cg_babble.hs;cg_babble.fs', '', 't_fi_host_bus_errors', 'FM-047', 'combine_na=fault injection test')
row('REQ-PERF-001', 'axi_master_dma', 'normal', 'Sustained isochronous IN rate without FIFO overflow at CLK-BUS 100 MHz', 'three 1024-byte packets per microframe for 1000 microframes', 'chk_perf;chk_data_e2e', 'cg_perf.rate_met', '', 't_perf_iso_in', 'FM-049')
row('REQ-RTL-001', 'process', 'normal', 'RTL rule check and lint results recorded', 'vlsit_rtl_check.py and Verilator lint on the four wrappers', 'chk_review', 'cg_review.rtl_rule', '', 't_rev_process', '', 'combine_na=review requirement')
row('REQ-VER-001', 'process', 'normal', 'A protocol checker exists per interface and a USB BFM per role', 'review of the environment against section 5 of the plan', 'chk_review', 'cg_review.env', '', 't_rev_process')
row('REQ-VER-002', 'process', 'normal', 'TSCALE divides the timers; each timing requirement runs once at TSCALE=1; delivered netlists use 1', 'compare scaled and unscaled measurements; review of the delivery parameters', 'chk_timing;chk_review', 'cg_tscale.scaled;cg_tscale.one', '', 't_dir_timing_ts1;t_rev_process')
row('REQ-VER-003', 'process', 'normal', 'Interoperability tests and compliance pre-check list exist in the plan', 'review only: execution needs hardware (out of scope, section 2.2)', 'chk_review', 'cg_review.interop_list', '', 't_rev_process')
row('REQ-DFT-001', 'process', 'normal', 'Test mode overrides reset sources in the reset controller only; clock gates have a test enable', 'review of the reset controller and clock-gate instances', 'chk_review', 'cg_review.dft', '', 't_rev_process')

# Formal plan: property -> (kind, statement, requirement, assumptions, target, cover)
FORMAL = {
    'a_crc5': ('assert', 'parallel CRC5 equals the bit-serial definition for every 11-bit input', 'REQ-FUNC-003', 'none', 'unbounded (combinational equivalence)', 'c_crc5_all'),
    'a_crc16': ('assert', 'parallel CRC16 step equals eight bit-serial steps for every state and byte', 'REQ-FUNC-003', 'none', 'unbounded', 'c_crc16_all'),
    'a_fifo_inv': ('assert', 'read pointer never passes the write pointer; count never exceeds the region size', 'REQ-FUNC-027', 'region map legal per section 11 (assume, reviewed); one packet engine request at a time', 'unbounded by induction, depth 40 fallback', 'c_fifo_full;c_fifo_empty;c_fifo_wrap'),
    'a_fifo_dbuf': ('assert', 'buf_cur changes only at a packet commit or cancel', 'REQ-FUNC-029', 'same as a_fifo_inv', 'unbounded', 'c_dbuf_swap'),
    'a_xreg_word': ('assert', 'each accepted register write appears once, whole and in order on the other side', 'REQ-CLK-003', 'independent free-running clocks; writes only when xq_free is not 0', 'bounded, depth to be fixed in the pilot', 'c_xreg_full;c_xreg_two_regs'),
    'a_xreg_tag': ('assert', 'an update whose tag differs from the CSR-side tag does not change the field', 'REQ-REG-003', 'same clocks', 'bounded', 'c_tag_stale'),
    'a_xreg_free': ('assert', 'xq_free equals 8 minus the occupancy; a write at 0 sets xq_ovf and is dropped', 'REQ-REG-002', 'same clocks', 'bounded', 'c_xq_ovf'),
    'a_ocp_filter': ('assert', 'power is 0 within 2 cycles after 16 consecutive low samples with oc_en 1 and stays 0 until ocur is cleared and vbus_drv is written', 'REQ-FUNC-034', 'synchronized input', 'unbounded', 'c_ocp_trip;c_ocp_rearm'),
    'a_irq_level': ('assert', 'o_int_usb equals the registered OR of status AND enable', 'REQ-IF-008', 'none', 'unbounded', 'c_irq_set;c_irq_clear'),
    'a_rst_sync': ('assert', 'reset output asserts without a clock and releases two clock edges after the input release', 'REQ-RESET-001', 'none', 'unbounded', 'c_rst_release'),
    'a_cdc_struct': ('review', 'each crossing net belongs to a structure of section 7.2', 'REQ-CLK-002', 'crossing list extracted from the hierarchy', 'review record', 'none'),
}

RISKS = [
    ('Q-001', 'Protocol clause inventory: the requirement index uses the 77 REQ IDs of the specification, which cite the standard clauses; no separate PROTO-<standard>-<clause> rows are listed. Confirm, or name the clauses to add.', 'Completeness claim is limited to the specification requirements', OWNER),
    ('Q-002', 'Owner and reviewer names: rows use the placeholder dv_usb2. Give the engineer names for owner, reviewer and gate approver.', 'G0 record and report reviews need named people', OWNER),
    ('Q-003', 'Coverage targets of section 9 are proposals. Confirm or change them before any run.', 'Closure criteria', OWNER),
    ('RISK-001', 'Verilator has no SystemVerilog covergroups and only simple immediate/concurrent assertions; functional bins are counted by the monitors and the Python model, assertion activity by counters.', 'Coverage and non-vacuity evidence is produced by project code, not by a simulator database', OWNER),
    ('RISK-002', 'No commercial formal or CDC tool; SymbiYosys with multi-clock designs gives bounded results for the register crossing.', 'CDC proofs are bounded; REQ-CLK-002 is a structural review', OWNER),
    ('RISK-003', 'The RTL and this plan were written with the same AI model. The protocol model must be written from the USB 2.0, UTMI+ and ULPI documents without RTL bodies.', 'Correlated-error risk between DUT and oracle', OWNER),
    ('RISK-004', 'Simulation speed of full-chip runs and of the TSCALE=1 timing tests is not measured yet; a pilot run fixes the runtime budget.', 'Runtime budget of tier full; may need a reduced measurement set', OWNER),
    ('RISK-005', 'Mutation testing has no tool here; a hand-made bug library (one bug per failure mode) is proposed instead.', 'Mutation score is a bug-library kill rate', OWNER),
    ('RISK-006', 'The 26 scratch benches in verification/ were written while the RTL was developed and read RTL signals; they stay as development history and are not evidence for this plan.', 'No credit from earlier runs', OWNER),
]
